import java.util.concurrent.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Queue;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;


public class CommunicationChannel {
	BlockingQueue<Message> messageFromHQs = new ArrayBlockingQueue<Message>(10000);
	BlockingQueue<Message> messageFromSpaceExplorers = new ArrayBlockingQueue<Message>(10000);
	
	//long workingThread = -1;

	Semaphore semPut = new Semaphore(1);
	Semaphore semGet = new Semaphore(1);
	Semaphore semPut2 = new Semaphore(1);


	public CommunicationChannel() {
	}

	
	public void putMessageSpaceExplorerChannel(Message message) {
		try{
			messageFromSpaceExplorers.put(message);
		}catch(Exception e){}
	}

	
	public Message getMessageSpaceExplorerChannel() {
		Message message = null;
		try{
			message = messageFromSpaceExplorers.take();
		}catch(Exception e){}

		return message;
	}


	ConcurrentHashMap<Long, ArrayBlockingQueue<Message>> tabela = new ConcurrentHashMap<>();
	public void putMessageHeadQuarterChannel(Message message) {

		if(message.getData().equals(HeadQuarter.EXIT) || 
			message.getData().equals(HeadQuarter.END) ){
				try {
					semPut2.acquire();
					messageFromHQs.put(message);	
				} catch (Exception e) {}
				semPut2.release();
				return;
		}

		long currentThread = Thread.currentThread().getId();

		if(!tabela.containsKey(currentThread)) {
			tabela.put(currentThread, new ArrayBlockingQueue<Message>(2));
		}

		if(tabela.get(currentThread).size() != 2) {
			tabela.get(currentThread).offer(message);
		}

		if(tabela.get(currentThread).size() == 2) {
			try{
				Message message1 = tabela.get(currentThread).remove();
				Message message2 = tabela.get(currentThread).remove();

				semPut2.acquire();
				messageFromHQs.put(new Message(message1.getCurrentSolarSystem(), message2.getCurrentSolarSystem(), message2.getData()));

			}catch(Exception e){}
			semPut2.release();
		}

		// try{
		// 	semPut.acquire();

		// 	if(message.getData().equals(HeadQuarter.EXIT) || 
		// 		message.getData().equals(HeadQuarter.END) ){
		// 			messageFromHQs.put(message);
		// 			//return;
		// 	}else{
		// 		ArrayBlockingQueue<Message> coada = new ArrayBlockingQueue<>(2);
		// 		coada = tabela.get(currentThread);	
		// 		coada.put(message);	//va avea un singur element daca cheia exista si nu avea mapata valoare 
		// 								//sau daca cheia nu exista in tabela
		// 		if(coada.size() == 2){	
		// 			try{
		// 				semPut2.acquire();

		// 				messageFromHQs.add(coada.remove());
		// 				messageFromHQs.add(coada.remove()); 
						
						
		// 			}catch(Exception e1){}
		// 			semPut2.release();
		// 		}else{
		// 			tabela.put(currentThread, coada);
		// 		}

		// 	}
		// }catch(Exception e){}
		
		// semPut.release();
	}

	
	public Message getMessageHeadQuarterChannel() {
		Message message = null;

		// try{
		// 	semGet.acquire();
		// 	try{
		// 		message1 = messageFromHQs.take();//parinte
		// 		if(message1.getData().equals(HeadQuarter.EXIT) ||
		// 			message1.getData().equals(HeadQuarter.END)){
		// 				return message1;
		// 		}
	
		// 		message2 = messageFromHQs.take();//copil
		// 	}catch(Exception e){}
		// }catch(Exception ex){}
		
		// semGet.release();
		
		// message = new Message(message1.getCurrentSolarSystem(), message2.getCurrentSolarSystem(), message2.getData());

		try {
			message = messageFromHQs.take();
		} catch (Exception e) {}

		return message;
	}
}



		// Long threadId = Thread.currentThread().getId();
		// if(tabela.containsKey(threadId) && tabela.get(threadId) != null){
		// 	try{
		// 		messageFromHQs.put(tabela.get(threadId));
		// 		messageFromHQs.put(message);
		// 		tabela.replace(threadId, null);
		// 	}catch(Exception ex){}	
		// }else{
		// 	if(tabela.containsKey(threadId) && tabela.get(threadId) == null){
		// 		if(message.getData().compareTo(HeadQuarter.EXIT) == 0 || 
		// 			message.getData().compareTo(HeadQuarter.END) == 0){
		// 				try{
		// 					messageFromHQs.put(message);
		// 				}catch(Exception e){}
		// 			}else{
		// 				tabela.replace(threadId, message);
		// 			}
		// 	}else{
		// 		if(message.getData().compareTo(HeadQuarter.EXIT) == 0 || 
		// 			message.getData().compareTo(HeadQuarter.END) == 0){
		// 				try{
		// 					messageFromHQs.put(message);
		// 				}catch(Exception e){}
		// 		}else{
		// 			tabela.put(threadId, message);
		// 		}
				
		// 	}
		// }

			

		// if(message.getData().compareTo(HeadQuarter.EXIT) == 0 || 
		// 	message.getData().compareTo(HeadQuarter.END) == 0)
		// 	{
		// 		ArrayBlockingQueue<Message> q = tabela.remove(threadId);
		// 		messageFromHQs.addAll(q);
		// 	}